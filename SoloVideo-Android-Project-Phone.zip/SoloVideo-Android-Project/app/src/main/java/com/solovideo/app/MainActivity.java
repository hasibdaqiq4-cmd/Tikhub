package com.solovideo.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.MediaController;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private final ArrayList<Uri> videos = new ArrayList<>();
    private int current = 0;
    private VideoView videoView;
    private TextView emptyText;
    private TextView counter;
    private float downX, downY;
    private static final int PICK_VIDEOS = 101;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.BLACK);
        getWindow().setNavigationBarColor(android.graphics.Color.BLACK);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);

        videoView = new VideoView(this);
        FrameLayout.LayoutParams videoParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(videoView, videoParams);

        emptyText = new TextView(this);
        emptyText.setText("Solo Video\n\nویدیوهای خودت را انتخاب کن");
        emptyText.setTextColor(0xFFFFFFFF);
        emptyText.setTextSize(22);
        emptyText.setGravity(Gravity.CENTER);
        root.addView(emptyText, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(16, 12, 16, 12);
        top.setBackgroundColor(0x66000000);
        counter = new TextView(this);
        counter.setTextColor(0xFFFFFFFF);
        counter.setTextSize(14);
        top.addView(counter, new LinearLayout.LayoutParams(0, -2, 1));

        Button pick = new Button(this);
        pick.setText("انتخاب ویدیو");
        pick.setOnClickListener(v -> chooseVideos());
        top.addView(pick);

        FrameLayout.LayoutParams topParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP);
        root.addView(top, topParams);

        videoView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                downX = event.getX(); downY = event.getY(); return true;
            }
            if (event.getAction() == MotionEvent.ACTION_UP) {
                float dx = event.getX() - downX;
                float dy = event.getY() - downY;
                if (Math.abs(dy) > 90 && Math.abs(dy) > Math.abs(dx)) {
                    if (dy < 0) playAt(current + 1); else playAt(current - 1);
                } else if (Math.abs(dx) < 40 && Math.abs(dy) < 40) {
                    if (videoView.isPlaying()) videoView.pause(); else videoView.start();
                }
                return true;
            }
            return true;
        });

        setContentView(root);
        updateCounter();
    }

    private void chooseVideos() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(intent, PICK_VIDEOS);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_VIDEOS || resultCode != RESULT_OK || data == null) return;
        videos.clear();
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                Uri uri = data.getClipData().getItemAt(i).getUri();
                keepPermission(data, uri);
                videos.add(uri);
            }
        } else if (data.getData() != null) {
            Uri uri = data.getData();
            keepPermission(data, uri);
            videos.add(uri);
        }
        current = 0;
        playAt(current);
    }

    private void keepPermission(Intent data, Uri uri) {
        try {
            getContentResolver().takePersistableUriPermission(uri,
                data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
        } catch (Exception ignored) { }
    }

    private void playAt(int index) {
        if (videos.isEmpty()) return;
        if (index < 0) index = videos.size() - 1;
        if (index >= videos.size()) index = 0;
        current = index;
        emptyText.setVisibility(View.GONE);
        videoView.setVisibility(View.VISIBLE);
        videoView.setVideoURI(videos.get(current));
        videoView.setOnPreparedListener(mp -> {
            mp.setLooping(true);
            videoView.start();
        });
        updateCounter();
    }

    private void updateCounter() {
        if (counter != null) counter.setText(videos.isEmpty()
            ? "Solo Video • آفلاین"
            : (current + 1) + " / " + videos.size() + "  •  بالا/پایین بکش");
    }

    @Override protected void onPause() {
        super.onPause();
        if (videoView != null && videoView.isPlaying()) videoView.pause();
    }
}
