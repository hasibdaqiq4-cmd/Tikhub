# Solo Video (starter Android project)

This is a starter project for an offline, local-video player. It requests no Internet permission and uses Android's document picker to let you choose videos stored on your phone.

## Build APK in GitHub Actions
1. Create a new GitHub repository named `SoloVideo` (a public repository is easiest for a first try).
2. Upload the contents of this ZIP to the repository root (not the ZIP file itself).
3. Open the repository's **Actions** tab and enable Actions if asked.
4. The `Build Solo Video APK` workflow starts after pushing to `main`. You can also open it and choose **Run workflow**.
5. Open the completed run, scroll to **Artifacts**, and download `SoloVideo-debug-apk`.
6. Extract the downloaded artifact and install `app-debug.apk` on your phone. Android may ask you to allow installation from your browser/files app.

## Notes
- This is a starter version, not a tested final release.
- The first build needs internet on GitHub's build server to download Android build dependencies; the installed app itself has no Internet permission.
- Swipe up/down to move through selected videos; tap the video to pause/resume.
